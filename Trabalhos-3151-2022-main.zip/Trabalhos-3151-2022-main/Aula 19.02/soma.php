<?php
    $a = $_POST["val1"];
    $b = $_POST["val2"];
    echo "Soma: ".$a + $b."<br>";
    echo "Diferença: ".$a - $b."<br>";
    echo "Produto: ".$a * $b."<br>";
    echo "Divisão: ".$a / $b;
?>