<?php
    $a = 10;
    echo $a;
    
?>