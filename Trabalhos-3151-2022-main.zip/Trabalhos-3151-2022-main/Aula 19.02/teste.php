<?php
    echo "Olá turma!";
    
?>