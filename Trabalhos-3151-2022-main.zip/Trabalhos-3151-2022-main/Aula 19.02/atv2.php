<?php
//soma
    $a = 10;
    $b = 5;
    echo "Soma: ".$a+$b."<br>";
    echo "Diferença: ".$a-$b."<br>";
    echo "Produto: ".$a*$b."<br>";
    echo "Divisão: ".$a/$b;
/*
linha 1
linha 2 
linha 3
*/
?>