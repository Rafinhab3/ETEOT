<?php
    echo "Olá mundo!";
    
?>