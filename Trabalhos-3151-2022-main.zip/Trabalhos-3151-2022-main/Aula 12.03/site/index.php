<?php
echo "<table>";
for ($i=1; $i <= 5; $i++) { 
    echo "<tr><td><img width='190px' src='img/img$i.jpg'></td></tr>";
}
echo "</table>";
?>