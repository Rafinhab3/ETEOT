<?php 

$vet1 = array("user" => "ana", "pwd" => "123","nivel" => 1);

echo $vet1['user']."<br>";
echo $vet1['pwd']."<br>";
echo $vet1['nivel']."<br>";
echo "-------------------<br>";

$vet2 = array(1,2,3);
echo $vet2[0]."<br>";
echo $vet2[1]."<br>";
echo $vet2[2]."<br>";

echo "-------------------<br>";

$vet3 = array("ALFA","BRAVO","CHARLIE");
echo $vet3[0]."<br>";
echo $vet3[1]."<br>";
echo $vet3[2]."<br>";


?>